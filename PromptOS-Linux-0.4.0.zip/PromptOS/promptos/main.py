import tkinter as tk
from tkinter import messagebox
from .app import PromptOSApp

def main():
    try:
        root=tk.Tk()
        PromptOSApp(root)
        root.mainloop()
    except Exception as exc:
        try: messagebox.showerror("PromptOS could not start",str(exc))
        except Exception: print(f"PromptOS: {exc}")
        raise

if __name__ == "__main__": main()
