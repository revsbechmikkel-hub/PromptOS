import tkinter as tk
from tkinter import ttk, messagebox
from .core import hardware, model_choices, ollama_status

CATEGORIES={"chat_general":"Everyday chat & writing","coding":"Programming & debugging","reasoning_math":"Reasoning & mathematics","vision_multimodal":"Images & screenshots"}
class SetupWizard(tk.Toplevel):
    def __init__(self, master, on_done):
        super().__init__(master); self.title("PromptOS Setup Wizard"); self.geometry("660x520"); self.minsize(580,460)
        self.on_done=on_done; self.hw=hardware(); self.category=tk.StringVar(value="chat_general"); self.speed=tk.StringVar(value="balanced"); self.model=tk.StringVar()
        self.configure(bg="#111827"); self._style(); self._page=0; self._build()
        self.transient(master); self.grab_set()
    def _style(self):
        s=ttk.Style(self); s.theme_use("clam"); s.configure("TFrame",background="#111827"); s.configure("TLabel",background="#111827",foreground="#e5e7eb",font=("Arial",11)); s.configure("Title.TLabel",font=("Arial",22,"bold"),foreground="#ffffff"); s.configure("TButton",padding=9); s.configure("TRadiobutton",background="#111827",foreground="#e5e7eb")
    def _build(self):
        self.body=ttk.Frame(self,padding=24); self.body.pack(fill="both",expand=True)
        self.title_lbl=ttk.Label(self.body,text="Welcome to PromptOS",style="Title.TLabel"); self.title_lbl.pack(anchor="w",pady=(0,8))
        self.desc=ttk.Label(self.body,text="Let's prepare your private local AI workstation."); self.desc.pack(anchor="w",pady=(0,18))
        self.content=ttk.Frame(self.body); self.content.pack(fill="both",expand=True)
        foot=ttk.Frame(self.body); foot.pack(fill="x",pady=(14,0))
        self.status=ttk.Label(foot,text="Step 1 of 4"); self.status.pack(side="left")
        self.next=ttk.Button(foot,text="Next →",command=self.advance); self.next.pack(side="right")
        self.render()
    def render(self):
        for w in self.content.winfo_children(): w.destroy()
        if self._page==0:
            ttk.Label(self.content,text="Your hardware",font=("Arial",15,"bold")).pack(anchor="w",pady=6)
            for line in [f"Operating system: {self.hw['os']}",f"CPU: {self.hw['cpu']}",f"System memory: {self.hw['ram_gb']} GB",f"Graphics: {self.hw['gpu']}"]:
                ttk.Label(self.content,text=line).pack(anchor="w",pady=5)
            ttk.Label(self.content,text="Model sizes are estimates. Actual memory use depends on context length and runtime settings.",wraplength=550).pack(anchor="w",pady=14)
        elif self._page==1:
            ttk.Label(self.content,text="What will you use AI for?",font=("Arial",15,"bold")).pack(anchor="w",pady=8)
            for k,v in CATEGORIES.items(): ttk.Radiobutton(self.content,text=v,value=k,variable=self.category).pack(anchor="w",pady=7)
        elif self._page==2:
            ttk.Label(self.content,text="Choose your priority",font=("Arial",15,"bold")).pack(anchor="w",pady=8)
            for k,v in [("fast","Fast — smaller models"),("balanced","Balanced — good speed and quality"),("smart","Smart — use more available memory")]:
                ttk.Radiobutton(self.content,text=v,value=k,variable=self.speed).pack(anchor="w",pady=8)
        else:
            ttk.Label(self.content,text="Recommended models for this computer",font=("Arial",15,"bold")).pack(anchor="w",pady=8)
            self.choices=model_choices(self.category.get(),self.speed.get(),self.hw)
            vals=[f"{m['tag']}  ·  approx. {m.get('gb','?')} GB"+("  ★ Recommended" if m.get("recommended") else "") for m in self.choices]
            self.combo=ttk.Combobox(self.content,state="readonly",values=vals); self.combo.pack(fill="x",pady=10)
            self.combo.current(0); self.model.set(self.choices[0]["tag"])
            ttk.Label(self.content,text="The model downloads from Ollama. Large models can take significant time and disk space.",wraplength=540).pack(anchor="w",pady=12)
            ok,info=ollama_status(); ttk.Label(self.content,text=("Ollama is reachable." if ok else "Ollama is not running or not installed. You can install/start it after setup.")).pack(anchor="w",pady=4)
            self.combo.bind("<<ComboboxSelected>>",lambda e:self.model.set(self.choices[self.combo.current()]["tag"]))
        self.status.configure(text=f"Step {self._page+1} of 4")
        self.next.configure(text="Finish setup" if self._page==3 else "Next →")
    def advance(self):
        if self._page<3: self._page+=1; self.render(); return
        tag=self.model.get()
        try:
            from pathlib import Path
            import json
            cfg=Path.home()/".config/promptos"; cfg.mkdir(parents=True,exist_ok=True)
            (cfg/"settings.json").write_text(json.dumps({"model":tag,"category":self.category.get(),"speed":self.speed.get()},indent=2))
            self.on_done(tag); self.grab_release(); self.destroy()
        except Exception as e: messagebox.showerror("Setup failed",str(e),parent=self)
