from __future__ import annotations
import json, os, platform, shutil, subprocess, urllib.request, urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CATALOG = Path(os.environ.get("PROMPTOS_MODELS_JSON", ROOT / "models.json"))
OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")

def hardware():
    ram = 0.0
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal:"):
                ram = round(int(line.split()[1]) / 1048576, 1); break
    except OSError: pass
    gpu, vram = "Not detected (CPU mode)", 0.0
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.check_output(["nvidia-smi","--query-gpu=name,memory.total","--format=csv,noheader,nounits"], text=True, stderr=subprocess.DEVNULL, timeout=3).strip().splitlines()
            vals=[x.split(",") for x in out]
            vram=round(sum(float(x[1].strip()) for x in vals)/1024,1)
            gpu=f"NVIDIA {vals[0][0].strip()} ({len(vals)} GPU, {vram} GB VRAM)"
        except Exception: pass
    if not vram:
        total=0
        for p in Path("/sys/class/drm").glob("card*/device/mem_info_vram_total"):
            try:
                dev=p.parent
                if (dev/"vendor").read_text().strip()=="0x1002": total+=int(p.read_text())
            except Exception: pass
        if total:
            vram=round(total/1073741824,1); gpu=f"AMD Radeon ({vram} GB VRAM)"
    return {"os": platform.platform(), "cpu": platform.processor() or platform.machine(),
            "ram_gb": ram, "vram_gb": vram, "gpu": gpu}

def load_catalog():
    with CATALOG.open(encoding="utf-8") as f: return json.load(f)

def model_choices(category="chat_general", speed="balanced", hw=None):
    hw=hw or hardware(); cat=load_catalog()["categories"][category]
    ram=float(hw["ram_gb"]); vram=float(hw["vram_gb"])
    ram_budget=max(0,(ram-4)*.7)
    vram_budget=max(0,vram-1.5) if vram>=2 else 0
    if vram_budget: budget={"fast":min(vram_budget,3),"balanced":vram_budget,"smart":max(vram_budget,ram_budget)}[speed]
    else: budget={"fast":min(ram_budget,3),"balanced":min(ram_budget,6),"smart":ram_budget}[speed]
    items=[]
    for item in cat.get("recommended",[]):
        size=float(item.get("gb",0))
        if size <= budget: items.append({**item,"recommended":True})
    for tag in cat.get("more",[]):
        import re
        m=re.search(r'(?<![\w.])(\d+(?:\.\d+)?)([bm])(?![a-z0-9])',tag.split(":",1)[-1])
        if m:
            size=float(m.group(1))/(1000 if m.group(2)=="m" else 1)*.6+.4
            if size<=budget and all(x["tag"]!=tag for x in items):
                items.append({"tag":tag,"gb":round(size,1),"recommended":False})
    return items or sorted(cat.get("recommended",[]),key=lambda x:float(x.get("gb",999)))[:1]

def ollama_request(path, payload=None, timeout=5):
    data=None if payload is None else json.dumps(payload).encode()
    req=urllib.request.Request(OLLAMA_URL+path,data=data,headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=timeout) as r: return r.read().decode()

def ollama_status():
    try:
        with urllib.request.urlopen(OLLAMA_URL+"/api/tags",timeout=2) as r:
            data=json.loads(r.read()); return True,[m.get("name","") for m in data.get("models",[])]
    except Exception as e: return False,str(e)

def pull_model(tag, progress=None):
    req=urllib.request.Request(OLLAMA_URL+"/api/pull",data=json.dumps({"name":tag,"stream":True}).encode(),headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=3600) as r:
        for raw in r:
            if not raw.strip(): continue
            obj=json.loads(raw)
            if progress: progress(obj.get("status","Downloading…"),obj.get("completed"),obj.get("total"))
            if obj.get("error"): raise RuntimeError(obj["error"])

def chat(model, messages, callback):
    req=urllib.request.Request(OLLAMA_URL+"/api/chat",data=json.dumps({"model":model,"messages":messages,"stream":True}).encode(),headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=600) as r:
        for raw in r:
            if raw.strip():
                obj=json.loads(raw); chunk=obj.get("message",{}).get("content","")
                if chunk: callback(chunk)
                if obj.get("error"): raise RuntimeError(obj["error"])
