import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import json, threading
from pathlib import Path
from .core import hardware, ollama_status, pull_model, chat
from .wizard import SetupWizard

CFG=Path.home()/".config/promptos/settings.json"
class PromptOSApp:
    def __init__(self,root):
        self.root=root; root.title("PromptOS — Local AI"); root.geometry("1000x700"); root.minsize(760,540)
        self.root.configure(bg="#0b1220"); self.messages=[]; self.busy=False
        self.style=ttk.Style(); self.style.theme_use("clam")
        self.style.configure("TFrame",background="#111827"); self.style.configure("TLabel",background="#111827",foreground="#e5e7eb",font=("Arial",10))
        self.style.configure("Title.TLabel",font=("Arial",20,"bold"),foreground="#fff")
        self.style.configure("TButton",padding=8); self.style.configure("TCombobox",padding=5)
        self.settings=self.load_settings(); self.model=tk.StringVar(value=self.settings.get("model",""))
        self.build(); self.refresh_models()
        if not self.settings.get("model"): self.root.after(400,lambda:SetupWizard(root,self.setup_done))
    def load_settings(self):
        try:return json.loads(CFG.read_text())
        except Exception:return {}
    def save_settings(self):
        CFG.parent.mkdir(parents=True,exist_ok=True); CFG.write_text(json.dumps({**self.settings,"model":self.model.get()},indent=2))
    def build(self):
        shell=ttk.Frame(self.root,padding=14); shell.pack(fill="both",expand=True)
        top=ttk.Frame(shell); top.pack(fill="x",pady=(0,12))
        ttk.Label(top,text="PromptOS",style="Title.TLabel").pack(side="left")
        ttk.Label(top,text="  PRIVATE · LOCAL AI").pack(side="left",padx=12)
        ttk.Button(top,text="Setup wizard",command=lambda:SetupWizard(self.root,self.setup_done)).pack(side="right")
        ttk.Button(top,text="Models",command=self.model_dialog).pack(side="right",padx=6)
        bar=ttk.Frame(shell); bar.pack(fill="x",pady=(0,10))
        ttk.Label(bar,text="Model").pack(side="left")
        self.model_box=ttk.Combobox(bar,textvariable=self.model,state="readonly",width=32); self.model_box.pack(side="left",padx=8)
        self.model_box.bind("<<ComboboxSelected>>",lambda e:self.save_settings())
        ttk.Button(bar,text="Refresh",command=self.refresh_models).pack(side="left")
        self.connection=ttk.Label(bar,text="Checking Ollama…"); self.connection.pack(side="right")
        self.output=tk.Text(shell,wrap="word",bg="#0b1220",fg="#e5e7eb",insertbackground="white",relief="flat",font=("Arial",11),padx=14,pady=12)
        self.output.pack(fill="both",expand=True); self.output.configure(state="disabled")
        self.output.tag_configure("user",foreground="#93c5fd",spacing1=10,spacing3=5); self.output.tag_configure("assistant",foreground="#d1fae5",spacing1=10,spacing3=5); self.output.tag_configure("system",foreground="#fbbf24")
        bottom=ttk.Frame(shell); bottom.pack(fill="x",pady=(10,0))
        self.entry=tk.Text(bottom,height=3,wrap="word",bg="#1f2937",fg="white",insertbackground="white",relief="flat",font=("Arial",11))
        self.entry.pack(side="left",fill="x",expand=True,padx=(0,8)); self.entry.bind("<Control-Return>",lambda e:self.send())
        self.send_btn=ttk.Button(bottom,text="Send  ↵",command=self.send); self.send_btn.pack(side="right",fill="y")
        ttk.Label(shell,text="Ctrl + Enter to send  ·  Conversations stay on this computer").pack(anchor="w",pady=(7,0))
    def write(self,text,tag):
        self.output.configure(state="normal"); self.output.insert("end",text+"\n\n",tag); self.output.see("end"); self.output.configure(state="disabled")
    def setup_done(self,tag):
        self.settings=self.load_settings(); self.model.set(tag); self.refresh_models(); self.write(f"Setup complete. Selected model: {tag}","system")
        ok,info=ollama_status()
        if ok and tag not in info: self.write("The selected model is not downloaded yet. Open Models to download it.","system")
    def refresh_models(self):
        ok,info=ollama_status()
        if ok:
            self.connection.configure(text="● Ollama connected"); self.model_box.configure(values=info)
            if self.model.get() and self.model.get() not in info: self.connection.configure(text="● Ollama · model not downloaded")
            elif not self.model.get() and info: self.model.set(info[0])
        else: self.connection.configure(text="○ Ollama unavailable")
    def send(self):
        prompt=self.entry.get("1.0","end").strip()
        if not prompt or self.busy:return
        model=self.model.get()
        if not model: messagebox.showwarning("Choose a model","Run the setup wizard or download a model first."); return
        self.entry.delete("1.0","end"); self.write("You\n"+prompt,"user"); self.messages.append({"role":"user","content":prompt})
        self.busy=True; self.send_btn.configure(state="disabled"); self.write("PromptOS\n","assistant")
        self.output.configure(state="normal"); self.output.insert("end","", "assistant"); self.output.configure(state="disabled")
        def worker():
            chunks=[]
            try: chat(model,self.messages,lambda c:chunks.append(c))
            except Exception as e: chunks.append(f"\n[Error: {e}]")
            answer="".join(chunks)
            self.root.after(0,lambda:self.finish(answer))
        threading.Thread(target=worker,daemon=True).start()
    def finish(self,answer):
        self.write("PromptOS\n"+answer,"assistant")
        if not answer.startswith("\n[Error:"): self.messages.append({"role":"assistant","content":answer})
        self.busy=False; self.send_btn.configure(state="normal")
    def model_dialog(self):
        win=tk.Toplevel(self.root); win.title("Model manager"); win.geometry("520x260"); win.configure(bg="#111827"); win.transient(self.root)
        f=ttk.Frame(win,padding=18); f.pack(fill="both",expand=True)
        ttk.Label(f,text="Install an Ollama model",style="Title.TLabel").pack(anchor="w",pady=6)
        name=tk.StringVar(value="qwen3:4b"); ttk.Entry(f,textvariable=name).pack(fill="x",pady=8)
        status=ttk.Label(f,text="Enter a model tag, e.g. qwen3:4b"); status.pack(anchor="w")
        def start():
            tag=name.get().strip()
            if not tag:return
            btn.configure(state="disabled")
            def progress(msg,done,total):
                txt=msg+(f" ({done*100//total}%)" if done and total else "")
                self.root.after(0,lambda:status.configure(text=txt))
            def work():
                try: pull_model(tag,progress); result=f"Downloaded {tag}"
                except Exception as e: result=f"Download failed: {e}"
                self.root.after(0,lambda:(status.configure(text=result),btn.configure(state="normal"),self.refresh_models()))
            threading.Thread(target=work,daemon=True).start()
        btn=ttk.Button(f,text="Download model",command=start); btn.pack(anchor="e",pady=12)
