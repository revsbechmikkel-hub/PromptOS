import unittest
from promptos.core import model_choices

class PickerTests(unittest.TestCase):
    def test_recommends_small_model_for_low_memory(self):
        hw={"ram_gb":8,"vram_gb":0}
        choices=model_choices("chat_general","fast",hw)
        self.assertTrue(choices)
        self.assertLessEqual(float(choices[0]["gb"]),3.0)

    def test_categories_have_choices(self):
        hw={"ram_gb":32,"vram_gb":8}
        for category in ("chat_general","coding","reasoning_math","vision_multimodal"):
            self.assertTrue(model_choices(category,"balanced",hw))

if __name__=="__main__": unittest.main()
